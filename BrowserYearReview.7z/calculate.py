# -*- coding: utf-8 -*-
# Editor    PyCharm
# File   calculate |Author    Pfolg
# 2025/01/07 16:39
import os
import time
from datetime import datetime
import pytz
from pyecharts.charts import Bar, Page
from pyecharts import options as opts
from pyecharts.globals import ThemeType
# import 爆肝4小时的结果

def convert_time(time_str, format):
    # 解析时间字符串为 datetime 对象
    dt_utc = datetime.strptime(time_str, format)

    # 设置时区为 UTC
    dt_utc = dt_utc.replace(tzinfo=pytz.UTC)

    # 转换为本地时区（假设为 Asia/Shanghai）
    local_timezone = pytz.timezone('Asia/Shanghai')
    dt_local = dt_utc.astimezone(local_timezone)

    return str(dt_local).replace("+", " ").split(" ")[1]

# Edge
edgeFile = "BrowsingHistory.csv"
isfile = os.path.exists(edgeFile)
year = 2024
print("检测数据文件是否存在")
if isfile:
    print("开始读取数据")
    with open(edgeFile, "r", encoding="utf-8") as file:
        content = file.readlines()
        content.remove(content[0])
    print("读取完成\n正在分析数据")
    start_time = time.time()
    # print(content, "\n", type(content))
    # print()
    webDict_header = {}
    webDict_url = {}
    webDict_day = {}
    time_format = '%I:%M:%S %p %z'
    local_time_format = "%H:%M:%S"
    # lateTime = ["12:00:00 AM +00:00", None, None]
    # earlyTime = ["11:59:59 PM +00:00", None, None]
    lateTime = ["0:0:0", None, None]
    earlyTime = ["23:59:59", None, None]

    for i in range(len(content)):
        content[i] = content[i].split(",")
        header = content[i][3]
        if header not in webDict_header:
            item1, item2 = 1, content[i][2].split("/")[2]
        else:
            item1 = webDict_header[header][0] + 1
            item2 = webDict_header[header][1]

        webDict_header[header] = [item1, item2]

        if item2 not in webDict_url:
            webDict_url[item2] = 1
        else:
            webDict_url[item2] += 1

        x = content[i][0].replace("/", " ").split(" ")

        if x[2] == str(year):
            day = eval(x[0] + "/" + x[1] + "\"")
            if day not in webDict_day:
                webDict_day[day] = [1, {}]
                if header not in webDict_day[day][1]:
                    webDict_day[day] = [1, {header: 1}]
                else:
                    webDict_day[day][1][header] += 1
            else:
                webDict_day[day][0] += 1
                if header not in webDict_day[day][1]:
                    webDict_day[day][1][header] = 1
                else:
                    webDict_day[day][1][header] += 1

            t = convert_time(eval("\"{} {} {}".format(x[3], x[4], x[5])), time_format)  # 解决格式问题
            # print(t)
            if datetime.strptime(t, local_time_format) < datetime.strptime(earlyTime[0], local_time_format):
                earlyTime = [t, header, day]
            if datetime.strptime(t, local_time_format) > datetime.strptime(lateTime[0], local_time_format):
                lateTime = [t, header, day]

    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"数据分析用时: {elapsed_time:.6f} 秒\n正在进一步整理数据")
    # 分析标题数量并排序
    sortedDictByHeadline = dict(sorted(webDict_header.items(), key=lambda item: item[1][0], reverse=True))  # 降序
    # 分析域名数量并排序
    sortedDictByUrl = dict(sorted(webDict_url.items(), key=lambda item: item[1], reverse=True))
    # 分析日点击
    sortedDictByDay = dict(sorted(webDict_day.items(), key=lambda item: item[1][0], reverse=True))
    # print(sortedDictByHeadline)
    # print("https://so.csdn.net/so/search?spm=1000.2115.3001.4498&q=rich&t=&u=".split("/")[2])

    listHeader = []
    count = 0
    for i in sortedDictByHeadline.items():
        listHeader.append((i[0], i[1][0]))
        if count == 9:
            count = 0
            break
        else:
            count += 1
    listUrls = []
    for i in sortedDictByUrl.items():
        listUrls.append(i)
        if count == 9:
            count = 0
            break
        else:
            count += 1

    # print("12/11/2024 8:07:38 AM +00:00".replace("/", " ").split(" "))
    # print(webDict_day)
    listDay = []
    for i in sortedDictByDay.items():
        listDay.append((i[0], i[1][0]))
        if count == 9:
            count = 0
            break
        else:
            count += 1

    first_value = next(iter(sortedDictByDay.values()))[1]
    mostDayDict = list(sorted(first_value.items(), key=lambda item: item[1], reverse=True))

    mostDay_mostHeader = mostDayDict[0]
    # print()
    # print(mostDay_mostHeader)
    # print(earlyTime)
    # print(lateTime)
    des = (
        "# 这是你的**{}**年浏览器使用报告\n"
        "\n你有**{}**天在使用浏览器\n"
        "\n其中{}那天你疯狂点击了**{} {}**次\n"
        "\n在{}那天凌晨{}，你居然在浏览**{}**\n"
        "\n在{}那天深夜{}，你还在看**{}**\n"
        "新的一年，愿你平安顺遂，喜乐安康！").format(
        year, len(list(webDict_day.items())), listDay[0][0], *mostDay_mostHeader,
        earlyTime[2], earlyTime[0], earlyTime[1], lateTime[2], lateTime[0],
        lateTime[1])

    ######################## 绘制图像
    print("正在创建html文件")
    # 1. 网站访问排名
    # 创建柱状图
    bar = (
        Bar(init_opts=opts.InitOpts(theme=ThemeType.MACARONS))
        .add_xaxis([site[0] for site in listHeader])
        .add_yaxis("访问次数", [site[1] for site in listHeader], category_gap="60%")
        .set_global_opts(
            title_opts=opts.TitleOpts(title="网站访问排名 Top10"),
            xaxis_opts=opts.AxisOpts(name="网站"),
            yaxis_opts=opts.AxisOpts(name="访问次数"),
            toolbox_opts=opts.ToolboxOpts(),
            # datazoom_opts=opts.DataZoomOpts(),
        )
    )
    # 2. 域名排行
    urls = (
        Bar(init_opts=opts.InitOpts(theme=ThemeType.WESTEROS))
        .add_xaxis([site[0] for site in listUrls])
        .add_yaxis("访问次数", [site[1] for site in listUrls], category_gap="60%")
        .set_global_opts(
            title_opts=opts.TitleOpts(title="域名访问排名 Top10"),
            xaxis_opts=opts.AxisOpts(name="域名"),
            yaxis_opts=opts.AxisOpts(name="访问次数"),
            toolbox_opts=opts.ToolboxOpts(),
            # datazoom_opts=opts.DataZoomOpts(),
        )
    )

    # 3. 访问日排行
    days = (
        Bar(init_opts=opts.InitOpts(theme=ThemeType.WONDERLAND))
        .add_xaxis([site[0] for site in listDay])
        .add_yaxis("访问次数", [site[1] for site in listDay], category_gap="60%")
        .set_global_opts(
            title_opts=opts.TitleOpts(title="日访问排名 Top10"),
            xaxis_opts=opts.AxisOpts(name="日期"),
            yaxis_opts=opts.AxisOpts(name="访问次数"),
            toolbox_opts=opts.ToolboxOpts(),
            # datazoom_opts=opts.DataZoomOpts(),
        )
    )

    page = Page(layout=Page.DraggablePageLayout)
    page.add(bar, urls, days)
    page.render("graph.html")

    print("正在创建md文件")
    with open("description.md", "w", encoding="utf-8") as md:
        md.write(des)

    print("程序运行完成，请在本目录下浏览graph.html文件和description.md文件")
else:
    print("未发现数据文件，程序退出")
