/*
 * 这是我的PyQt的学习记录
 */
public class StudyRecord{
    public static void main(String[] args){
        for (String string : strs) {
            System.err.println(string);
        }
    }
    public static String[] strs={
        "2025年2月26日20:00:48=https://www.bilibili.com/video/BV11C4y1P7fj?spm_id_from=333.788.player.switch&vd_source=edfdd55f842e918612b57f0aa7ec277e&p=7",
        "2025年2月27日13:30:19=https://www.bilibili.com/video/BV11C4y1P7fj?spm_id_from=333.788.videopod.episodes&vd_source=edfdd55f842e918612b57f0aa7ec277e&p=8",
        "2025年2月27日19:57:43=https://www.bilibili.com/video/BV11C4y1P7fj?p=15",
        "2025年2月28日12:59:55=https://www.bilibili.com/video/BV11C4y1P7fj/?p=25&t=105"，
        "2025年2月28日22:29:23=https://www.bilibili.com/video/BV11C4y1P7fj?p=25",
        "2025年3月1日15:10:16=https://www.bilibili.com/video/BV11C4y1P7fj?p=40",
        "2025年3月1日16:30:56=https://www.bilibili.com/video/BV11C4y1P7fj?p=42",
        "2025年3月2日16:52:47=https://www.bilibili.com/video/BV11C4y1P7fj?p=53",
        "Over！！！&以此歌作结：メリーメリー"
    };
}
