# -*- coding: UTF-8 -*-
"""
PROJECT_NAME Python_projects
PRODUCT_NAME PyCharm
NAME run
AUTHOR Pfolg
TIME 2025/2/26 19:51
"""

from PyQt6.QtWidgets import QApplication, QPushButton, QDialog, QFontDialog, QColorDialog
import sys
from PyQt6 import uic


def select_font():
    font, ok = QFontDialog.getFont()
    if ok:
        print(font)


def select_color():  # 只会返回颜色
    r = QColorDialog.getColor()
    print(r)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ui = uic.loadUi("./ui.ui")
    pushButton: QPushButton = ui.pushButton
    pushButton2: QPushButton = ui.pushButton_2
    print(pushButton.text(), pushButton2.text())
    pushButton.clicked.connect(select_font)
    pushButton2.clicked.connect(select_color)
    ui.show()
    sys.exit(app.exec())
